# Solar Computer Platform Website

This is the Solar Computer Platform website.

## Files
- `index.html` — main website page
- `style.css` — design and responsive layout
- `script.js` — registration and product interactions

## GitHub Pages
Upload all three website files to the repository root, then enable GitHub Pages from the repository's **Settings → Pages** section and select the `main` branch as the source.

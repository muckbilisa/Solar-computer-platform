function showMessage(message) {
  alert(message);
}

document.getElementById("signupForm").addEventListener("submit", function (event) {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  document.getElementById("formMessage").textContent =
    `Welcome, ${name}! Your registration form is ready.`;
  this.reset();
});

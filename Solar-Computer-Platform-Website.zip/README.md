# Solar Computer Platform

A starter web platform where users can create accounts, explore products and services, and make purchases online.

## Files
- `index.html` — main website
- `style.css` — website design
- `script.js` — basic interactions

## Important
This version is a front-end prototype. Real user accounts, a database, and live payment/mobile-money processing still need to be connected before accepting real customer payments.
